using System.Data.SqlClient;

namespace Lab07_ADONET_Connection;

public class Form1 : Form
{
    private readonly TextBox txtServer = new();
    private readonly Button btnCheck = new();
    private readonly Button btnStatus = new();
    private readonly Label lblResult = new();
    private readonly TextBox txtDetails = new();

    public Form1()
    {
        Text = "Lab 07 - Kiểm tra kết nối SQL Server";
        Width = 760;
        Height = 480;
        StartPosition = FormStartPosition.CenterScreen;

        var lblServer = new Label { Text = "Tên SQL Server/Instance:", Left = 20, Top = 24, Width = 180 };
        txtServer.SetBounds(205, 20, 300, 28);
        txtServer.Text = @".";
        btnCheck.Text = "Kiểm tra kết nối";
        btnCheck.SetBounds(520, 19, 170, 30);
        btnCheck.Click += BtnCheck_Click;

        btnStatus.Text = "Xem trạng thái";
        btnStatus.SetBounds(520, 58, 170, 30);
        btnStatus.Click += BtnStatus_Click;

        lblResult.SetBounds(20, 62, 480, 30);
        lblResult.Text = "Chưa kiểm tra kết nối.";
        txtDetails.SetBounds(20, 105, 670, 300);
        txtDetails.Multiline = true;
        txtDetails.ReadOnly = true;
        txtDetails.ScrollBars = ScrollBars.Vertical;
        txtDetails.Font = new Font("Consolas", 10);

        Controls.AddRange(new Control[] { lblServer, txtServer, btnCheck, btnStatus, lblResult, txtDetails });
    }

    private string BuildConnectionString()
    {
        string server = string.IsNullOrWhiteSpace(txtServer.Text) ? "." : txtServer.Text.Trim();
        return $"Data Source={server};Initial Catalog=QLSinhVien;Integrated Security=True;TrustServerCertificate=True";
    }

    private void BtnCheck_Click(object? sender, EventArgs e)
    {
        try
        {
            using SqlConnection conn = new(BuildConnectionString());
            conn.Open();
            lblResult.Text = "Kết nối thành công!";
            lblResult.ForeColor = Color.DarkGreen;
            txtDetails.Text = $"Kết nối thành công.\r\nDatabase: {conn.Database}\r\nServer: {conn.DataSource}\r\nPhiên bản SQL Server: {conn.ServerVersion}\r\nTrạng thái: {conn.State}\r\nThời gian: {DateTime.Now:dd/MM/yyyy HH:mm:ss}";
        }
        catch (SqlException ex)
        {
            lblResult.Text = "Kết nối thất bại.";
            lblResult.ForeColor = Color.DarkRed;
            txtDetails.Text = "Không thể kết nối SQL Server.\r\n" + ex.Message +
                "\r\n\r\nHãy kiểm tra tên instance, dịch vụ SQL Server và database QLSinhVien.";
        }
        catch (Exception ex)
        {
            lblResult.Text = "Có lỗi xảy ra.";
            lblResult.ForeColor = Color.DarkRed;
            txtDetails.Text = ex.Message;
        }
    }

    private void BtnStatus_Click(object? sender, EventArgs e)
    {
        try
        {
            using SqlConnection conn = new(BuildConnectionString());
            var started = DateTime.Now;
            conn.Open();
            var elapsed = DateTime.Now - started;
            txtDetails.Text = $"DataSource: {conn.DataSource}\r\nDatabase: {conn.Database}\r\nServerVersion: {conn.ServerVersion}\r\nState: {conn.State}\r\nThời điểm kiểm tra: {DateTime.Now:dd/MM/yyyy HH:mm:ss}\r\nThời gian mở kết nối: {elapsed.TotalMilliseconds:0.##} ms";
            lblResult.Text = "Đã lấy trạng thái kết nối.";
            lblResult.ForeColor = Color.DarkGreen;
        }
        catch (Exception ex)
        {
            lblResult.Text = "Không lấy được trạng thái.";
            lblResult.ForeColor = Color.DarkRed;
            txtDetails.Text = ex.Message;
        }
    }
}
