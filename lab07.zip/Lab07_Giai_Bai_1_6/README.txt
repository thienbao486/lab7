LAB 07 - ADO.NET KẾT NỐI SQL SERVER
======================================

Nội dung:
- SQL/Lab07_QLSinhVien.sql: tạo database QLSinhVien, bảng, dữ liệu mẫu và ràng buộc.
- Lab07_ADONET_Connection: project WinForms kiểm tra kết nối SQL Server.
- BaoCao/Lab07_BaiTap_1_6.docx: báo cáo lời giải bài 1-6.

CÁCH CHẠY SQL
1. Mở SQL Server Management Studio (SSMS), kết nối đúng instance SQL Server.
2. Mở SQL/Lab07_QLSinhVien.sql.
3. Chọn Execute (F5), kiểm tra các bảng Khoa, SinhVien, HocPhan, DangKy.
4. Script tạo lại các bảng của bài lab nếu đã tồn tại, vì vậy hãy sao lưu dữ liệu cũ trước khi chạy lại.

CÁCH CHẠY PROJECT WINFORMS
1. Cài Visual Studio 2022 với workload .NET desktop development và .NET 8 SDK.
2. Mở file Lab07_ADONET_Connection.csproj.
3. Nếu SQL Server của bạn không dùng instance mặc định, sửa ô Tên SQL Server/Instance trên giao diện:
   - Instance mặc định: .
   - SQL Express thường gặp: .\SQLEXPRESS
   - Instance khác: TENMAY\TENINSTANCE
4. Đảm bảo đã chạy script SQL và tạo database QLSinhVien.
5. Nhấn F5 chạy chương trình, bấm "Kiểm tra kết nối" hoặc "Xem trạng thái".

LƯU Ý
- Project dùng Windows Authentication (Integrated Security=True).
- Nếu dùng SQL Authentication, cần đổi connection string và đảm bảo tài khoản chỉ có quyền cần thiết.
- NuGet package System.Data.SqlClient sẽ được khôi phục khi build lần đầu.
- Đây là project WinForms dựng giao diện bằng code, không phụ thuộc Form Designer nên tránh lỗi event handler bị thiếu.
