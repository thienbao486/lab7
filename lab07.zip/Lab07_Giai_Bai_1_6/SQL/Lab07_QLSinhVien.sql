/*
    LAB 07 - QLSinhVien
    Bài 1-6: tạo CSDL, bảng, dữ liệu mẫu, lớp kết nối và ràng buộc bổ sung.
    Chạy toàn bộ script trong SQL Server Management Studio (SSMS).
*/
IF DB_ID(N'QLSinhVien') IS NULL
    CREATE DATABASE QLSinhVien;
GO

USE QLSinhVien;
GO

/* Cho phép chạy lại script: xóa bảng theo thứ tự phụ thuộc */
IF OBJECT_ID(N'dbo.DangKy', N'U') IS NOT NULL DROP TABLE dbo.DangKy;
IF OBJECT_ID(N'dbo.SinhVien', N'U') IS NOT NULL DROP TABLE dbo.SinhVien;
IF OBJECT_ID(N'dbo.HocPhan', N'U') IS NOT NULL DROP TABLE dbo.HocPhan;
IF OBJECT_ID(N'dbo.Khoa', N'U') IS NOT NULL DROP TABLE dbo.Khoa;
GO

/* Bài 2: bảng Khoa và SinhVien */
CREATE TABLE dbo.Khoa
(
    MaKhoa VARCHAR(10) NOT NULL PRIMARY KEY,
    TenKhoa NVARCHAR(100) NOT NULL UNIQUE
);
GO

CREATE TABLE dbo.SinhVien
(
    MaSV VARCHAR(15) NOT NULL PRIMARY KEY,
    HoTen NVARCHAR(100) NOT NULL,
    NgaySinh DATE NOT NULL,
    GioiTinh BIT NOT NULL,
    MaKhoa VARCHAR(10) NOT NULL,
    DiemTB DECIMAL(4,2) NOT NULL CONSTRAINT DF_SinhVien_DiemTB DEFAULT (0),
    Email VARCHAR(100) NULL,
    CONSTRAINT CK_SinhVien_Diem CHECK (DiemTB BETWEEN 0 AND 10),
    CONSTRAINT FK_SinhVien_Khoa FOREIGN KEY (MaKhoa) REFERENCES dbo.Khoa(MaKhoa)
);
GO

/* Bài 3: bảng HocPhan và DangKy */
CREATE TABLE dbo.HocPhan
(
    MaHP VARCHAR(10) NOT NULL PRIMARY KEY,
    TenHP NVARCHAR(120) NOT NULL,
    SoTinChi INT NOT NULL,
    CONSTRAINT CK_HocPhan_SoTinChi CHECK (SoTinChi BETWEEN 1 AND 6)
);
GO

CREATE TABLE dbo.DangKy
(
    MaSV VARCHAR(15) NOT NULL,
    MaHP VARCHAR(10) NOT NULL,
    HocKy INT NOT NULL,
    NgayDangKy DATE NOT NULL CONSTRAINT DF_DangKy_NgayDangKy DEFAULT (CONVERT(date, GETDATE())),
    Diem DECIMAL(4,2) NULL,
    CONSTRAINT PK_DangKy PRIMARY KEY (MaSV, MaHP),
    CONSTRAINT CK_DangKy_HocKy CHECK (HocKy BETWEEN 1 AND 3),
    CONSTRAINT CK_DangKy_Diem CHECK (Diem IS NULL OR Diem BETWEEN 0 AND 10),
    CONSTRAINT FK_DangKy_SinhVien FOREIGN KEY (MaSV) REFERENCES dbo.SinhVien(MaSV),
    CONSTRAINT FK_DangKy_HocPhan FOREIGN KEY (MaHP) REFERENCES dbo.HocPhan(MaHP)
);
GO

/* Bài 4: dữ liệu mẫu - 3 khoa, 10 sinh viên, 5 học phần và đăng ký */
INSERT INTO dbo.Khoa(MaKhoa, TenKhoa) VALUES
('CNTT', N'Công nghệ thông tin'),
('OTO', N'Công nghệ kỹ thuật ô tô'),
('KT', N'Kinh tế');

INSERT INTO dbo.SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email) VALUES
('SV001', N'Nguyễn Văn An',   '2005-02-15', 1, 'CNTT', 8.20, 'an@eaut.edu.vn'),
('SV002', N'Trần Thị Bình',  '2005-07-21', 0, 'CNTT', 7.40, 'binh@eaut.edu.vn'),
('SV003', N'Lê Văn Cường',   '2004-12-03', 1, 'OTO',  6.80, 'cuong@eaut.edu.vn'),
('SV004', N'Phạm Thị Dung',  '2005-04-10', 0, 'KT',   8.60, 'dung@eaut.edu.vn'),
('SV005', N'Hoàng Văn Em',   '2004-09-18', 1, 'CNTT', 7.90, 'em@eaut.edu.vn'),
('SV006', N'Vũ Thị Giang',   '2005-11-02', 0, 'OTO',  7.10, 'giang@eaut.edu.vn'),
('SV007', N'Đặng Văn Hùng',  '2005-01-27', 1, 'KT',   6.50, 'hung@eaut.edu.vn'),
('SV008', N'Bùi Thị Lan',    '2004-06-14', 0, 'CNTT', 9.10, 'lan@eaut.edu.vn'),
('SV009', N'Đỗ Văn Minh',    '2005-08-30', 1, 'OTO',  7.70, 'minh@eaut.edu.vn'),
('SV010', N'Ngô Thị Nhung',  '2004-03-08', 0, 'KT',   8.00, 'nhung@eaut.edu.vn');

INSERT INTO dbo.HocPhan(MaHP, TenHP, SoTinChi) VALUES
('HP001', N'Lập trình .NET', 3),
('HP002', N'Cơ sở dữ liệu',  3),
('HP003', N'Lập trình C#',   4),
('HP004', N'Mạng máy tính',  3),
('HP005', N'Phân tích thiết kế hệ thống', 3);

INSERT INTO dbo.DangKy(MaSV, MaHP, HocKy, Diem) VALUES
('SV001','HP001',1,8.50), ('SV001','HP002',1,8.00),
('SV002','HP001',1,7.50), ('SV002','HP003',2,7.00),
('SV003','HP002',1,6.50), ('SV003','HP004',2,7.00),
('SV004','HP005',1,8.50), ('SV005','HP001',1,8.00),
('SV006','HP003',2,7.50), ('SV007','HP004',1,6.00),
('SV008','HP002',1,9.00), ('SV009','HP005',2,7.50),
('SV010','HP001',1,8.00);
GO

/* Bài 6: bổ sung ràng buộc UNIQUE Email (cho phép nhiều giá trị NULL) */
ALTER TABLE dbo.SinhVien
ADD CONSTRAINT UQ_SinhVien_Email UNIQUE (Email);
GO

/* Kiểm tra dữ liệu */
SELECT * FROM dbo.Khoa ORDER BY MaKhoa;
SELECT * FROM dbo.SinhVien ORDER BY MaSV;
SELECT * FROM dbo.HocPhan ORDER BY MaHP;
SELECT * FROM dbo.DangKy ORDER BY MaSV, MaHP;

SELECT sv.MaSV, sv.HoTen, k.TenKhoa, sv.DiemTB
FROM dbo.SinhVien AS sv
INNER JOIN dbo.Khoa AS k ON sv.MaKhoa = k.MaKhoa
ORDER BY sv.MaSV;

SELECT hp.TenHP, COUNT(dk.MaSV) AS SoSinhVienDangKy
FROM dbo.HocPhan AS hp
LEFT JOIN dbo.DangKy AS dk ON hp.MaHP = dk.MaHP
GROUP BY hp.TenHP
ORDER BY hp.TenHP;

/* Bài 6 - thử dữ liệu vi phạm (bỏ chú thích từng câu để kiểm tra lỗi):
   1) Email trùng:
   INSERT INTO dbo.SinhVien(MaSV,HoTen,NgaySinh,GioiTinh,MaKhoa,DiemTB,Email)
   VALUES ('SV011',N'Sinh viên thử','2005-01-01',1,'CNTT',7.0,'an@eaut.edu.vn');

   2) Điểm trung bình ngoài [0,10]:
   INSERT INTO dbo.SinhVien(MaSV,HoTen,NgaySinh,GioiTinh,MaKhoa,DiemTB,Email)
   VALUES ('SV012',N'Sinh viên sai điểm','2005-01-01',1,'CNTT',11,'sv12@eaut.edu.vn');

   3) Học kỳ ngoài [1,3]:
   INSERT INTO dbo.DangKy(MaSV,MaHP,HocKy,Diem) VALUES ('SV001','HP005',4,8.0);
*/
